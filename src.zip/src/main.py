import sys

mazeXml = sys.argv[1]

actions = ""
print(actions)